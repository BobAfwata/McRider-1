﻿namespace McRider_V2._0
{
    internal class BluetoothDeviceInfo
    {
        public object DeviceAddress { get; internal set; }
    }
}