﻿namespace BluetoothPersonal
{
    internal class Sockets
    {
    }
}