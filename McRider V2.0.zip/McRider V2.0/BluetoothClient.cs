﻿namespace McRider_V2._0
{
    internal class CustomBluetoothClient
    {

       
    }
}
